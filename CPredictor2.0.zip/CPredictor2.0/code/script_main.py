from __future__ import division
import numpy as np
import networkx as nx
import scripts.script_module as mod
import os


'''

one layer mcl
'''

def main(ppiService, funcService, 
         func_lvl = 2, 
         f_is_valid_den = lambda x:True, 
         thre_merge = 0.8,
         show_bm = False, compService = None):  
      
    d_func_genes = funcService.get_d_func_genes(func_lvl)
    
    predService = mod.PredService()
    preds = list()
    
    # extract func-sub pin & get connected components    
    for func_name in d_func_genes:
        dpin = ppiService.get_dynamicPIN( d_func_genes[func_name ])
        subs = list(nx.connected_component_subgraphs(dpin, copy = False))
        for sub in subs:
            if len(sub)<=1: 
                continue
            preds.append( sub )
    
    if show_bm == True and False: ##
        print compService.bm(preds, 0.2, 2)
        
    # make sure the density of predicted clusters are valid, if not then performing mcl on sparse cluster
    preds_den_parse = list()
            
    for pred in preds:
        den = len(pred.edges())/(len(pred)*(len(pred)-1)/2)
                    
        if f_is_valid_den( len(pred), den ) == True:
            preds_den_parse.append( pred )
   
    preds = preds_den_parse
    if show_bm == True and False: ##
        print compService.bm(preds, 0.2, 2)
    # merge 
    preds = predService.merge(preds, weighted = False, thre_ov = thre_merge)
    if show_bm == True:
        #print compService.bm(preds, 0.2, 2)
        #print '\t'.join( map('{:.3f}'.format, compService.bm(preds, 0.2, 2)) )
        res1 = compService.bm_small(preds)
        res2 = compService.bm_large(preds)
        res3 = compService.bm_all(preds)
        print '\t'.join( ['', '', '', ''] 
                         + map('{:.3f}'.format ,res1) 
                         + map('{:.3f}'.format ,res2)
                         + map('{:.3f}'.format ,res3)
                         )
    return preds

if __name__ == '__main__':
    
    
    # data prepare
    fn_funcat = '../data/funcat-2.1_data_20070316'
    funcService = mod.FuncService(fn_funcat)

    path_ppi = '../data/ppi/%s.tab'
    path_complex = '../data/complex/%s.tab'
    ppis = ['krogan','gavin','collins']
    comps = ['MIPS','CYC2008']

    for comp in comps:
        for ppi in ppis:
            _fn_comp = path_complex%(comp,)
            _fn_ppi = path_ppi%(ppi,)
            print os.path.basename( _fn_comp),'\t', os.path.basename(_fn_ppi)
            
            ppiService = mod.PPIService(_fn_ppi)
            compService = mod.ComplexService(_fn_comp)
            
            # parameter
            func_lvl = 6
            def f_is_valid_den(size, den):
                if den >= 0.3: return True
                else: return False        
                
            thre_merge = 0.8,
               
            preds = main(ppiService, funcService, func_lvl, f_is_valid_den = f_is_valid_den, 
                     thre_merge = thre_merge, show_bm = False, compService = compService)


            #output
            fo = open('CPredict.%s.tab'%(ppi,),'w')
            for pred in preds:
                fo.write('\t'.join(pred)+'\n')
            fo.flush()
            fo.close()
    print 'END'
