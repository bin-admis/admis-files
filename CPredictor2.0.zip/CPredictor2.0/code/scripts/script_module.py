from __future__ import division
import networkx as nx
from mcl_clustering import my_mcl_cluster
import numpy as np

class FuncService():
    def __init__(self, fn):
        self._pairs_gene_func = list()
        for line in open(fn):
            strs = line.upper().split('|')
            gene = strs[0].strip()
            func = strs[1].strip()
            if func.startswith('-'): continue
            self._pairs_gene_func.append( (gene, func) )
    
    def get_d_func_genes(self, lvl = 1):
        '''
        get gene grous by d_func_genes
        parameter: lvl (default = 1), eg: 11.10.20 -> 11
        return
            dict (func_name, set(genes))
        '''
        d_func_genes = dict()
        for gene, func in self._pairs_gene_func:
            strs = func.split('.')
            if strs[0] in ('-', '99'): continue
            fun_name = '.'.join(strs[:lvl])            
            d_func_genes.setdefault(fun_name, set())
            d_func_genes[fun_name].add(gene)
        return d_func_genes
    
    def get_d_func_genes_prefix(self, lvl = 1):
        '''
        for level = 2;
        11.10 & 11 is the same
        '''
        g = nx.Graph()
        d_gene_funcs = dict()
        for gene, func in self._pairs_gene_func:
            strs = func.split('.')
            if strs[0] in ('-', '99'): continue
            fun_name = '.'.join(strs[:lvl])            
            d_gene_funcs.setdefault(gene, set())
            d_gene_funcs[gene].add(fun_name)

        genes = d_gene_funcs.keys()
        for i1 in range(len(genes)-1):
            gene1 = genes[i1]
            funcs1 = d_gene_funcs[gene1]
            for i2 in range(i1+1, len(genes)):
                gene2 = genes[i2]
                funcs2 = d_gene_funcs[gene2]
                is_link = False
                for func1 in funcs1:
                    for func2 in funcs2:
                        if func1.startswith(func2)==True or func2.startswith(func1)==True:
                            is_link = True
                            break
                    if is_link == True:
                        break
                if is_link:
                    g.add_edge(gene1, gene2)
        
        # get 
        print '--'
        cliques = nx.find_cliques(g)
        return cliques
            
    def get_d_gene_funcs(self, lvl = 1):
        d_gene_funcs = dict()
        for gene, func in self._pairs_gene_func:
            strs = func.split('.')
            if strs[0] in ('-', '99'): continue
            fun_name = '.'.join(strs[:lvl])    
            d_gene_funcs.setdefault(gene, set())
            d_gene_funcs[gene].add(fun_name)
        return d_gene_funcs
        
class PPIService():
    
    def __init__(self, fn):
        self._ppis = list()
        ppis_text = set() 
        self._pin = nx.Graph()
        for line in open(fn):
            strs = line.upper().split()
            
            weight = float(strs[2]) if len(strs) == 3 else 1
                
            strs = strs[0:2]
            ppi = sorted([s.strip() for s in strs])
            ppi_text = ' '.join(ppi)
            
            if ppi_text not in ppis_text:
                ppis_text.add( ppi_text )
                
                self._ppis.append (ppi)                
                self._pin.add_edge(ppi[0], ppi[1], w = weight)
        
    def get_ppis(self):
        return self._ppis
    
    def get_staticPIN(self):
        return self._pin
        
    def get_dynamicPIN(self, genes):
        '''
        return graph
        '''        
        return self._pin.subgraph( genes )
        
class ComplexService():
    def __init__(self, fn):
        comps = list()
        for line in open(fn):
            comp = line.upper().strip().split()
            if len(comp)<2: continue
            comps.append(comp)
        self._comps = comps
    
    def get_proteins(self):
        proteins = set()
        for comp in self._comps:
            for c in comp:
                proteins.add(c)
        return list(proteins)
    
    def get_complexes(self):
        return self._comps        

    def bm(self, predicts, _w = 0.2, _min_size = 2):
        comps = map(set, filter(lambda x:len(x)>=_min_size, self._comps))
        preds = map(set, filter(lambda x:len(x)>=_min_size, predicts))
        confusion = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                confusion[i,j] = len(set.intersection(comps[i], preds[j]))
                
        w = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                w[i,j] = confusion[i,j]**2/(len(comps[i])*len(preds[j]))
                
        n_r = sum([1 if any(w[i,:]>=_w) else 0 for i in range(len(comps))])
        n_p = sum([1 if any(w[:,j]>=_w) else 0 for j in range(len(preds))])
    
        r = n_r/len(comps) if len(comps)>0 else 0
        p = n_p/len(preds) if len(preds)>0 else 0
        f1 = 2*p*r/(p+r) if(p+r)!=0 else 0
        
        z = sum([len(pred) for pred in preds])
        sn = sum([max(confusion[:,j]) for j in range(len(preds))])/z if z>0 else 0
        z = np.sum(confusion)
        ppv = sum([max(confusion[i,:]) for i in range(len(comps))])/z if z>0 else 0
        acc = np.sqrt(sn * ppv)
        
        return [r,p,f1,sn,ppv,acc]
    
    def bm_small(self, predicts, _w =0.2):
        comps = map(set, filter(lambda x:len(x) in (2,3), self._comps))
        preds = map(set, filter(lambda x:len(x) in (2,3), predicts))
        
        confusion = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                confusion[i,j] = len(set.intersection(comps[i], preds[j]))
                
        w = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                w[i,j] = confusion[i,j]**2/(len(comps[i])*len(preds[j]))
                
        n_r = sum([1 if any(w[i,:]>=_w) else 0 for i in range(len(comps))])
        n_p = sum([1 if any(w[:,j]>=_w) else 0 for j in range(len(preds))])
    
        r = n_r/len(comps) if len(comps)>0 else 0
        p = n_p/len(preds) if len(preds)>0 else 0
        f1 = 2*p*r/(p+r) if(p+r)!=0 else 0
        
        z = sum([len(pred) for pred in preds])
        sn = sum([max(confusion[:,j]) for j in range(len(preds))])/z if z>0 else 0
        z = np.sum(confusion)
        ppv = sum([max(confusion[i,:]) for i in range(len(comps))])/z if z>0 else 0
        acc = np.sqrt(sn * ppv)
        
        return [r,p,f1,sn,ppv,acc]
        
    
    
    def bm_large(self, predicts, _w = 0.2):
        comps = map(set, filter(lambda x:len(x) > 3 , self._comps))
        preds = map(set, filter(lambda x:len(x) > 3, predicts))
        
        confusion = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                confusion[i,j] = len(set.intersection(comps[i], preds[j]))
                
        w = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                w[i,j] = confusion[i,j]**2/(len(comps[i])*len(preds[j]))
                
        n_r = sum([1 if any(w[i,:]>=_w) else 0 for i in range(len(comps))])
        n_p = sum([1 if any(w[:,j]>=_w) else 0 for j in range(len(preds))])
    
        r = n_r/len(comps) if len(comps)>0 else 0
        p = n_p/len(preds) if len(preds)>0 else 0
        f1 = 2*p*r/(p+r) if(p+r)!=0 else 0
        
        z = sum([len(pred) for pred in preds])
        sn = sum([max(confusion[:,j]) for j in range(len(preds))])/z if z>0 else 0
        z = np.sum(confusion)
        ppv = sum([max(confusion[i,:]) for i in range(len(comps))])/z if z>0 else 0
        acc = np.sqrt(sn * ppv)
        
        return [r,p,f1,sn,ppv,acc]
    def bm_all(self, predicts, _w =0.2):
        comps = map(set, filter(lambda x:len(x) >= 2, self._comps))
        preds = map(set, filter(lambda x:len(x) >= 2, predicts))
        
        confusion = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                confusion[i,j] = len(set.intersection(comps[i], preds[j]))
                
        w = np.zeros(len(comps)*len(preds)).reshape(len(comps), len(preds))
        for i in range(len(comps)):
            for j in range(len(preds)):
                w[i,j] = confusion[i,j]**2/(len(comps[i])*len(preds[j]))
                
        n_r = sum([1 if any(w[i,:]>=_w) else 0 for i in range(len(comps))])
        n_p = sum([1 if any(w[:,j]>=_w) else 0 for j in range(len(preds))])
    
        r = n_r/len(comps) if len(comps)>0 else 0
        p = n_p/len(preds) if len(preds)>0 else 0
        f1 = 2*p*r/(p+r) if(p+r)!=0 else 0
        
        z = sum([len(pred) for pred in preds])
        sn = sum([max(confusion[:,j]) for j in range(len(preds))])/z if z>0 else 0
        z = np.sum(confusion)
        ppv = sum([max(confusion[i,:]) for i in range(len(comps))])/z if z>0 else 0
        acc = np.sqrt(sn * ppv)
        
        return [r,p,f1,sn,ppv,acc]

class PredService():
    
    def _density(self, pred):
        return len(pred.edges())/(len(pred)*(len(pred)-1)/2) 
    def _weighted_density(self, pred):
        return sum([d['w'] for (u,v,d) in pred.edges(data=True)])/(len(pred)*(len(pred)-1)/2)

    def mcl(self, subgraph):
        return [subgraph.subgraph(x) for x in my_mcl_cluster(subgraph)]
        
    def mcl_on_low_density(self, preds, weighted = False, thre_den = 0.5):
        new_preds = []
        f_den = self._density if weighted == True else self._weighted_density
        for pred in preds:
            if f_den(pred) >= thre_den:
                new_preds.append( pred )
            else:
                for mcl in my_mcl_cluster(pred):
                    if len(mcl) >= 2:
                        sub = pred.subgraph(mcl) 
                        if f_den(sub) >= thre_den:
                            new_preds.append(sub)
        return new_preds
            
    def _ov(self, pred1, pred2):    
        a = len( filter(lambda x:x in pred2, pred1) ) 
        return a/max(len(pred1),len(pred2))
    
    def merge(self, preds, weighted = False, thre_ov = 0.6):
        ov_g = nx.Graph()
        for i in range(len(preds)-1):
            for j in range(i+1, len(preds)-1):
                ov = self._ov(preds[i], preds[j]);
                if ov >= thre_ov:
                    ov_g.add_edge(i,j)
             
        new_preds = list()
               
        for i in range(len(preds)):
            if i not in ov_g:
                new_preds.append( preds[i] )                
        
        f_den = self._density if weighted == False else self._weighted_density
        conns = nx.connected_components(ov_g)
        for conn in conns:
            if len(conn) == 1:
                new_preds.append( preds[conn] )
            else:
                dens = [f_den(preds[p]) for p in conn]
                i = np.argmax(dens)
                new_preds.append( preds[conn[i]] )
        return new_preds
    
    def run(self, preds, weighted = False, thre_den = 0.5):
        n_preds = self.mcl_on_low_density(preds, weighted = weighted, thre_den = thre_den)
        return self.merge(n_preds, weighted)
 
    def output(self, fn, preds):
        with open(fn, 'w') as fo:
            fo.write( '\n'.join(map('\t'.join, preds)) )
        
    
    
if __name__ == '__main__':
    pass
    '''
    # fn_funcat = '../Data/cygd/catalogues/d_func_genes/d_func_genes-2.1_data_20070316'
    
    fn_ppi = '../Data/PPI/gavin'
    ppis = load_ppi(fn_ppi)
    print len(ppis)
    print ppis[0]
    '''